<?php
if($_POST){

  if (empty($_POST["first_name"])){
    $first_nameError = "Nome é um campo obrigatório!!";
  }else{
    $first_name = test_input($_POST["first_name"]);
  }

  if (empty($_POST["last_name"])){
    $last_nameError = "Apelido é um campo obrigatório!!";
  }else{
    $last_name = test_input($_POST["last_name"]);
  }

  if (empty($_POST["email"])){
    $emailError = "Email é um campo obrigatório!!";
  }else{
    $email = test_input($_POST["email"]);
  }

  if (empty($_POST["city"])){
    $cityError = "Localidade é um campo obrigatório!!";
  }else{
    $city = test_input($_POST["city"]);
  }

  if (!empty($_FILES["uploaded_file"])){
    $path = "uploads/";
    $path = $path . basename( $_FILES['uploaded_file']['$name']); /* mudar o path mais tarde - seficar o first_name pode causar problemas de futuro*/
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) {
      echo "O ficheiro ". basename( $_FILES['uploaded_file']['name']). "foi submetido.";
    }else{
      echo "Ocorreu um erro durante o upload.";
    }
  }
}

function test_input($data){
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
//Load Composer's autoloader

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->isSMTP();
    $mail->SMTPDebug = 2;                             // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'rcarneiropro@gmail.com';                 // SMTP username
    $mail->Password = 'cardoso96carneiro';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->SMTPAutoTLS = false;
    $mail->Port = 587;                                    // TCP port to connect to

    //Workaround - makes it work for PHPMailer 5.2.10 and newer versions
    $mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
    );
    //Recipients
    $mail->setFrom('rcarneiropro@gmail.com', 'GymStar', 0);
    $mail->addAddress('28457@esccb.pt');     // Add a recipient

    //Email Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Inscrição GymStar';
    $mail->Body    = 'Olá ' . $first_name . ' ' . $last_name . ',
    <br>Obrigado por ter submetido a sua inscrição. Vamos analisá-la e caso seja aceite será notificado.
    <br>Os dados que submeteu foram os seguintes:
    <br><ul><b>Nome: </b>' . $first_name . ' ' . $last_name . '</ul>
    <ul><b>Email: </b>' .  $email . '</ul>
    <ul><b>Localidade: </b>' . $city . '</ul>
    <br> Cumprimentos, <br> GymStar.';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}

?>
