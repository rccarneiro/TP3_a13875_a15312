<?php
$connection = mysqli_connect('localhost','root','mysql','TP3') or die(mysqli_error($connection));
?>
